#ifndef ARCHIVOMANAGER_H
#define ARCHIVOMANAGER_H
#include "Contabilidad.h"

class ArchivoManager {
public:
    static void guardarDatos(const Contabilidad& contabilidad, const string& filename);
    static void cargarDatos(Contabilidad& contabilidad, const string& filename);
};
#endif