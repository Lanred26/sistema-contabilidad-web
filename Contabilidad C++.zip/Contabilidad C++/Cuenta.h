#ifndef CUENTA_H
#define CUENTA_H
#include <iostream>
#include <string>

using namespace std;
class Cuenta {
protected:
    string nombre;
    double debe; 
    double haber;

public:
    Cuenta(string n = "", double d = 0.0, double h = 0.0) 
        : nombre(n), debe(d), haber(h) {}
    virtual ~Cuenta() {}

    string getNombre() const { return nombre; }
    double getDebe() const { return debe; }
    double getHaber() const { return haber; }

    void registrarMovimiento(double cargo, double abono) {
        debe += cargo;
        haber += abono;
    }
    virtual double calcularSaldo() const = 0;
    virtual string getTipo() const = 0;
    virtual string getSubtipo() const = 0;

    virtual void mostrar() const {
        cout << "Cuenta: " << nombre << " | Debe: $" << debe << " | Haber: $" << haber << " | Saldo: $" << calcularSaldo() << endl;
    }
};

// --- ACTIVOS ---
class ActivoCirculante : public Cuenta {
public:
    ActivoCirculante(string n, double d = 0, double h = 0) : Cuenta(n, d, h) {}
    string getTipo() const override { return "Activo"; }
    string getSubtipo() const override { return "Circulante"; }
    double calcularSaldo() const override {
        return debe - haber;
    }
};

class ActivoFijo : public Cuenta {
public:
    ActivoFijo(string n, double d = 0, double h = 0) : Cuenta(n, d, h) {}
    string getTipo() const override { return "Activo"; }
    string getSubtipo() const override { return "Fijo"; }
    double calcularSaldo() const override { return debe - haber; }
};

// --- PASIVOS ---
class PasivoCortoPlazo : public Cuenta {
public:
    PasivoCortoPlazo(string n, double d = 0, double h = 0) : Cuenta(n, d, h) {}
    string getTipo() const override { return "Pasivo"; }
    string getSubtipo() const override { return "Corto Plazo"; }
    double calcularSaldo() const override {
        return haber - debe;
    }
};

// --- CAPITAL ---
class CapitalContable : public Cuenta {
public:
    CapitalContable(string n, double d = 0, double h = 0) : Cuenta(n, d, h) {}
    string getTipo() const override { return "Capital"; }
    string getSubtipo() const override { return "Capital Contable"; }
    double calcularSaldo() const override {
        return haber - debe;
    }
};

#endif