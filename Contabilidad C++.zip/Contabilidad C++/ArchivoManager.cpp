#include "ArchivoManager.h"
#include <fstream>
#include <sstream>
#include <cstdlib>

void ArchivoManager::guardarDatos(const Contabilidad& contabilidad, const string& filename) {
    ofstream archivo(filename.c_str());
    if (!archivo.is_open()) return;

    const vector<Cuenta*>& cuentas = contabilidad.getCuentas();
    for (size_t i = 0; i < cuentas.size(); ++i) {
        archivo << cuentas[i]->getTipo() << "|" 
                << cuentas[i]->getSubtipo() << "|" 
                << cuentas[i]->getNombre() << "|" 
                << cuentas[i]->getDebe() << "|" 
                << cuentas[i]->getHaber() << "\n";
    }
    archivo.close();
}

void ArchivoManager::cargarDatos(Contabilidad& contabilidad, const string& filename) {
    ifstream archivo(filename.c_str());
    if (!archivo.is_open()) return;
    contabilidad.limpiarCuentas();
    string linea;
    while (getline(archivo, linea)) {
        stringstream ss(linea);
        string tipo, subtipo, nombre, tempDebe, tempHaber;
        if (getline(ss, tipo, '|') && getline(ss, subtipo, '|') && 
            getline(ss, nombre, '|') && getline(ss, tempDebe, '|') && getline(ss, tempHaber)) {
            double debe = atof(tempDebe.c_str());
            double haber = atof(tempHaber.c_str());
            if (tipo == "Activo") {
                if (subtipo == "Circulante") contabilidad.agregarCuenta(new ActivoCirculante(nombre, debe, haber));
                else contabilidad.agregarCuenta(new ActivoFijo(nombre, debe, haber));
            } else if (tipo == "Pasivo") {
                contabilidad.agregarCuenta(new PasivoCortoPlazo(nombre, debe, haber));
            } else if (tipo == "Capital") {
                contabilidad.agregarCuenta(new CapitalContable(nombre, debe, haber));
            }
        }
    }
    archivo.close();
}