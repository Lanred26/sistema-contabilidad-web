#include "Contabilidad.h"

Contabilidad::~Contabilidad() {
    limpiarCuentas();
}

void Contabilidad::limpiarCuentas() {
    for (size_t i = 0; i < cuentas.size(); ++i) {
        delete cuentas[i];
    }
    cuentas.clear();
}

void Contabilidad::agregarCuenta(Cuenta* c) {
    cuentas.push_back(c);
}

void Contabilidad::listarCuentas() const {
    if (cuentas.empty()) {
        cout << "\nNo hay cuentas registradas.\n";
        return;
    }
    cout << "\n--- LISTADO DE CUENTAS CONTABLES ---\n";
    for (size_t i = 0; i < cuentas.size(); ++i) {
        cout << i + 1 << ". [" << cuentas[i]->getTipo() << " - " << cuentas[i]->getSubtipo() << "] ";
        cuentas[i]->mostrar();
    }
}

void Contabilidad::registrarMovimientoEnCuenta(int indice, double cargo, double abono) {
    if (indice >= 0 && indice < (int)cuentas.size()) {
        cuentas[indice]->registrarMovimiento(cargo, abono);
        cout << "Movimiento registrado con exito.\n";
    } else {
        cout << "Indice de cuenta invalido.\n";
    }
}

double Contabilidad::calcularTotalActivos() const {
    double total = 0;
    for (size_t i = 0; i < cuentas.size(); ++i) {
        if (cuentas[i]->getTipo() == "Activo") {
            total += cuentas[i]->calcularSaldo();
        }
    }
    return total;
}

double Contabilidad::calcularTotalPasivos() const {
    double total = 0;
    for (size_t i = 0; i < cuentas.size(); ++i) {
        if (cuentas[i]->getTipo() == "Pasivo") {
            total += cuentas[i]->calcularSaldo();
        }
    }
    return total;
}

double Contabilidad::calcularTotalCapital() const {
    double total = 0;
    for (size_t i = 0; i < cuentas.size(); ++i) {
        if (cuentas[i]->getTipo() == "Capital") {
            total += cuentas[i]->calcularSaldo();
        }
    }
    return total;
}

void Contabilidad::mostrarResumenFinanciero() const {
    double act = calcularTotalActivos();
    double pas = calcularTotalPasivos();
    double cap = calcularTotalCapital();
    double pasivoMasCapital = pas + cap;

    cout << "\n========================================\n";
    cout << "         BALANCE GENERAL / RESUMEN      \n";
    cout << "========================================\n";
    cout << " Total Activos:       $" << act << endl;
    cout << " Total Pasivos:       $" << pas << endl;
    cout << " Total Capital:       $" << cap << endl;
    cout << "----------------------------------------\n";
    cout << " Suma (Pasivo + Cap): $" << pasivoMasCapital << endl;
    
    if (act == pasivoMasCapital) {
        cout << " Estado: [CUADRADO] La ecuacion contable es correcta.\n";
    } else {
        cout << " Estado: [DESCUADRE] Revisa tus cargos y abonos.\n";
    }
    cout << "========================================\n";
}