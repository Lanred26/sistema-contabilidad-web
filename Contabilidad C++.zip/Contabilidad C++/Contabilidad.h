#ifndef CONTABILIDAD_H
#define CONTABILIDAD_H
#include <vector>
#include "Cuenta.h"

class Contabilidad {
private:
    vector<Cuenta*> cuentas;

public:
    ~Contabilidad();
    void agregarCuenta(Cuenta* c);
    void listarCuentas() const;
    void registrarMovimientoEnCuenta(int indice, double cargo, double abono);
    double calcularTotalActivos() const;
    double calcularTotalPasivos() const;
    double calcularTotalCapital() const;
    void mostrarResumenFinanciero() const;
    const vector<Cuenta*>& getCuentas() const { return cuentas; }
    void limpiarCuentas();
};

#endif