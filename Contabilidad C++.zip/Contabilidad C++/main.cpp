#include <iostream>
#include "Contabilidad.h"
#include "ArchivoManager.h"

using namespace std;

int main() {
    Contabilidad miContabilidad;
    string archivoBD = "contapack_data.txt";
    ArchivoManager::cargarDatos(miContabilidad, archivoBD);

    int opcion = 0;
    do {
        cout << "\n========================================\n";
        cout << "    SISTEMA CONTABLE (TIPO CONTAPACK)   \n";
        cout << "========================================\n";
        cout << "1. Crear nueva cuenta contable\n";
        cout << "2. Registrar Cargo (Debe) o Abono (Haber)\n";
        cout << "3. Listar cuentas y saldos\n";
        cout << "4. Ver Resumen Financiero (Balance)\n";
        cout << "5. Guardar y Salir\n";
        cout << "Seleccione una opcion: ";
        cin >> opcion;

        if (cin.fail()) {
            cin.clear();
            cin.ignore(10000, '\n');
            cout << "Entrada invalida.\n";
            continue;
        }

        switch (opcion) {
            case 1: {
                int tipoOpc, subOpc;
                string nombre;
                cout << "\n--- CREAR CUENTA ---\n";
                cout << "1. Activo\n2. Pasivo\n3. Capital\nElige tipo: ";
                cin >> tipoOpc;
                cout << "Nombre de la cuenta (ej. Bancos, Proveedores): ";
                cin.ignore();
                getline(cin, nombre);
                if (tipoOpc == 1) {
                    cout << "1. Activo Circulante\n2. Activo Fijo\nElige subtipo: ";
                    cin >> subOpc;
                    if (subOpc == 1) miContabilidad.agregarCuenta(new ActivoCirculante(nombre));
                    else miContabilidad.agregarCuenta(new ActivoFijo(nombre));
                } else if (tipoOpc == 2) {
                    miContabilidad.agregarCuenta(new PasivoCortoPlazo(nombre));
                } else if (tipoOpc == 3) {
                    miContabilidad.agregarCuenta(new CapitalContable(nombre));
                } else {
                    cout << "Opcion incorrecta.\n";
                    break;
                }
                cout << "¡Cuenta creada exitosamente!\n";
                break;
            }
            case 2: {
                miContabilidad.listarCuentas();
                int idx;
                double cargo, abono;
                cout << "\nNumero de cuenta a modificar: ";
                cin >> idx;
                cout << "Monto de Cargo (Debe): $";
                cin >> cargo;
                cout << "Monto de Abono (Haber): $";
                cin >> abono;
                miContabilidad.registrarMovimientoEnCuenta(idx - 1, cargo, abono);
                break;
            }
            case 3:
                miContabilidad.listarCuentas();
                break;
            case 4:
                miContabilidad.mostrarResumenFinanciero();
                break;
            case 5:
                ArchivoManager::guardarDatos(miContabilidad, archivoBD);
                cout << "\nDatos guardados. Saliendo...\n";
                break;
            default:
                cout << "Opcion no valida.\n";
        }
    } while (opcion != 5);

    return 0;
}